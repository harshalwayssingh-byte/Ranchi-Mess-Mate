# MessMate Android

Installable Android demo for a mess delivery/attendance workflow.

## One-click APK build (recommended)
1. Create a GitHub account and a new empty repository named `messmate`.
2. Upload the entire contents of this folder (not the ZIP itself).
3. Open the repo → **Actions** → **Build MessMate APK** → **Run workflow**.
4. Wait for the green check.
5. Open the workflow run → **Artifacts** → download `MessMate-debug-apk`.
6. Extract it and install the `.apk` on Android. If Android asks, allow installation from the browser/file manager.

This demo works locally on one device. The `DELIVERED` button records delivery and shows a local notification. It does NOT yet send a notification from a staff phone to a different member phone.

## Production version
For real multi-phone sync, create a Firebase project and connect Android Firebase Authentication + Firestore + Firebase Cloud Messaging. The app screens can then be wired to a shared database and real push notifications.
