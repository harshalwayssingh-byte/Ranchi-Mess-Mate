package com.messmate.app;

import android.Manifest;
import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.view.*;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, content; TextView title; String meal="Lunch";
    final String[] members={"Rahul Kumar|Room 101","Amit Kumar|Room 102","Priya Singh|Room 103","Neha Kumari|Room 104","Rohit Kumar|Room 105"};
    android.content.SharedPreferences sp;
    int blue=Color.rgb(37,99,235), green=Color.rgb(22,163,74), red=Color.rgb(220,38,38);
    @Override public void onCreate(Bundle b){super.onCreate(b); sp=getSharedPreferences("mess",0); requestNotif(); showRole();}
    void requestNotif(){ if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},9); }
    TextView tv(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(Color.rgb(15,23,42));t.setPadding(18,14,18,14);return t;}
    Button btn(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);return b;}
    void base(String heading){ root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.rgb(248,250,252));
      LinearLayout bar=new LinearLayout(this);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setPadding(10,10,10,10);title=tv(heading,22);title.setTypeface(null,1);bar.addView(title,new LinearLayout.LayoutParams(0,60,1));
      Button back=btn("Home");back.setOnClickListener(v->showRole());bar.addView(back,new LinearLayout.LayoutParams(100,60));root.addView(bar); ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(12,8,12,30);sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));setContentView(root); }
    void showRole(){base("🍱 MessMate");content.addView(tv("Choose your role",20));content.addView(tv("This is the first installable demo. Real multi-phone sync and push notifications are added after Firebase setup.",15));
      Button a=btn("👨‍💼  Admin Dashboard");a.setOnClickListener(v->admin());content.addView(a); Button s=btn("👨‍🍳  Staff Delivery");s.setOnClickListener(v->staff());content.addView(s);Button m=btn("👤  Member App");m.setOnClickListener(v->member());content.addView(m); }
    void admin(){base("👨‍💼 Admin Dashboard");int delivered=countDelivered();content.addView(tv("Today — "+date(),22));content.addView(tv("Members: "+members.length+"    Delivered: "+delivered+"    Pending: "+(members.length-delivered),18));
      content.addView(tv("Delivery overview",20));for(String x:members){String n=x.split("\\|")[0];boolean d=sp.getBoolean(key(n),false);content.addView(tv((d?"✅ ":"⏳ ")+n+" — "+(d?"Delivered":"Pending"),17));}
      Button reset=btn("Reset today's demo deliveries");reset.setOnClickListener(v->{for(String x:members)sp.edit().remove(key(x.split("\\|")[0])).apply();admin();});content.addView(reset); }
    void staff(){base("👨‍🍳 Staff Delivery");content.addView(tv("Today's "+meal,22));Button switchMeal=btn("Switch to "+(meal.equals("Lunch")?"Dinner":"Lunch"));switchMeal.setOnClickListener(v->{meal=meal.equals("Lunch")?"Dinner":"Lunch";staff();});content.addView(switchMeal);
      for(String x:members){String[] p=x.split("\\|");String n=p[0], room=p[1];boolean d=sp.getBoolean(key(n),false);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);TextView info=tv(n+"\n"+room,17);row.addView(info,new LinearLayout.LayoutParams(0,75,1));Button b=btn(d?"Delivered ✅":"DELIVERED");b.setEnabled(!d);b.setOnClickListener(v->{sp.edit().putBoolean(key(n),true).apply();notifyMember(n);staff();});row.addView(b,new LinearLayout.LayoutParams(130,70));content.addView(row);}}
    void member(){base("👤 Member App");String n="Rahul Kumar";boolean d=sp.getBoolean(key(n),false);content.addView(tv("Welcome, "+n+" 👋",22));content.addView(tv("Today's meal",18));content.addView(tv(d?"🍱 "+meal+" — DELIVERED ✅":"🍱 "+meal+" — Pending ⏳",24));if(d)content.addView(tv("Delivered at "+time(),16));content.addView(tv("\n📅 October Attendance",20));content.addView(tv("🟢 Delivered    🔴 Not delivered\n\n3 Oct: "+(d?"🟢":"🔴")+"\nPrevious demo days: 🟢 🟢 🟢 🔴 🟢",17));}
    String key(String n){return "del_"+n.replace(" ","_");} int countDelivered(){int c=0;for(String x:members)if(sp.getBoolean(key(x.split("\\|")[0]),false))c++;return c;}
    String date(){return new SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(new Date());}String time(){return new SimpleDateFormat("hh:mm a",Locale.getDefault()).format(new Date());}
    void notifyMember(String name){NotificationManager nm=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);String channel="delivery";if(android.os.Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(channel,"Meal Delivery",NotificationManager.IMPORTANCE_HIGH));Notification.Builder b=android.os.Build.VERSION.SDK_INT>=26?new Notification.Builder(this,channel):new Notification.Builder(this);b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("🍱 Meal Delivered").setContentText(name+", your "+meal.toLowerCase()+" has been delivered.").setAutoCancel(true);nm.notify((int)System.currentTimeMillis(),b.build());Toast.makeText(this,"Delivery marked for "+name,Toast.LENGTH_SHORT).show();}
}
