# MessMate

Polished single-app demo for mess management. One APK has role-based Admin, Staff/Delivery, and Member dashboards. This build is offline/demo mode; Firebase and cross-device push notifications are not connected yet.

## Build
Use the repository GitHub Actions workflow or Android/Gradle tooling.
