# Ranchi Mess Mate

Firebase-connected Android app for mess administration, delivery staff, and members.

## Current Firebase flow
- Email/password sign-in with Firebase Authentication.
- User role is read from Realtime Database at `users/{uid}/role`.
- Roles: `admin`, `staff`, `member`.
- Staff delivery writes go to `deliveries/{yyyy-MM-dd}/{Lunch|Dinner}/{memberUid}`.
- Member screens listen to their own delivery record in realtime.
- Firebase config is included in `app/google-services.json`.

## Assigning roles
Create the authentication account in Firebase Console, then add a matching Realtime Database profile:

```text
users/
  <AUTH_UID>/
    role: admin | staff | member
    name: Display Name
    memberId: optional-id
    room: optional-room
```

For a member, the app uses the Auth UID as the delivery record key.

## Realtime Database rules
See `database.rules.json`. Paste these rules into Firebase Console → Realtime Database → Rules before testing multi-user sync.

## Build
The repository workflow extracts this project ZIP and runs `:app:assembleDebug`.
