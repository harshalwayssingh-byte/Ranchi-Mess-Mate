# Ranchi Lunch Box

Android mess-management app with Firebase Authentication, Realtime Database, role-based Admin/Staff/Member screens, meal delivery tracking, attendance from deliveries, and the Ranchi Lunch Box brand/logo.

Package: `com.messmate.app`
