package com.messmate.app;

import android.Manifest;
import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;
import com.google.firebase.messaging.FirebaseMessaging;

import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root, body;
    FirebaseAuth auth;
    DatabaseReference db;
    FirebaseUser user;
    String role = "", currentName = "", memberId = "";
    String meal = "Lunch";
    final Map<String, DatabaseReference> listeners = new HashMap<>();
    final int NAVY=Color.rgb(23,63,45), MUTED=Color.rgb(91,112,100), GREEN=Color.rgb(31,107,79),
            GREEN2=Color.rgb(59,138,103), BG=Color.rgb(245,248,244), RED=Color.rgb(220,38,38),
            ORANGE=Color.rgb(205,133,35), BLUE=Color.rgb(37,99,235), GOLD=Color.rgb(217,164,65),
            BORDER=Color.rgb(218,228,220);

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        auth = FirebaseAuth.getInstance();
        db = FirebaseDatabase.getInstance("https://ranchi-mess-mate-default-rtdb.asia-southeast1.firebasedatabase.app").getReference();
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        requestNotif();
        if (auth.getCurrentUser() != null) loadProfile(auth.getCurrentUser()); else showLogin();
    }

    void requestNotif(){
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},9);
    }
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    TextView tv(String s,float size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    TextView bold(String s,float size,int color){TextView t=tv(s,size,color);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    GradientDrawable bg(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp((int)r));return g;}
    GradientDrawable stroke(int color,int line,int fill,float r){GradientDrawable g=bg(fill,r);g.setStroke(dp(line),color);return g;}
    Button btn(String s,int fill,int text){Button b=new Button(this);b.setText(s);b.setTextColor(text);b.setTextSize(15);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setGravity(Gravity.CENTER);b.setPadding(dp(12),0,dp(12),0);b.setBackground(bg(fill,18));return b;}
    LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(18),dp(16),dp(18),dp(16));c.setBackground(bg(Color.WHITE,22));c.setElevation(dp(2));return c;}
    LinearLayout h(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void root(){root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);setContentView(root);}
    void hide(View v){((InputMethodManager)getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(),0);}

    ImageView logo(int size){
        ImageView im=new ImageView(this);
        im.setImageResource(com.messmate.app.R.drawable.ranchi_lunch_box_logo);
        im.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        im.setContentDescription("Ranchi Lunch Box logo");
        im.setPadding(dp(2),dp(2),dp(2),dp(2));
        im.setAdjustViewBounds(true);
        im.setLayoutParams(new LinearLayout.LayoutParams(dp(size),dp(size)));
        return im;
    }

    void showLogin(){
        root(); ScrollView sc=new ScrollView(this); LinearLayout p=new LinearLayout(this); p.setOrientation(LinearLayout.VERTICAL); p.setPadding(dp(20),dp(28),dp(20),dp(28)); sc.addView(p); root.addView(sc,new LinearLayout.LayoutParams(-1,-1));
        LinearLayout logoWrap=new LinearLayout(this); logoWrap.setGravity(Gravity.CENTER); logoWrap.addView(logo(148));
        p.addView(logoWrap,new LinearLayout.LayoutParams(-1,dp(158)));
        TextView n=bold("Ranchi Lunch Box",34,NAVY); n.setGravity(Gravity.CENTER); p.addView(n);
        TextView sub=bold("SMART MESS • LUNCH • DELIVERY",11,GOLD); sub.setGravity(Gravity.CENTER); sub.setLetterSpacing(.12f); p.addView(sub);
        LinearLayout login=card(); login.setPadding(dp(20),dp(20),dp(20),dp(20)); LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.topMargin=dp(18); p.addView(login,lp);
        TextView w=bold("Welcome Back! 👋",25,NAVY); w.setGravity(Gravity.CENTER); login.addView(w); TextView hint=tv("Sign in with your registered email",14,MUTED); hint.setGravity(Gravity.CENTER); login.addView(hint);
        TextView le=bold("Email",14,NAVY); le.setPadding(0,dp(22),0,dp(7)); login.addView(le);
        EditText email=new EditText(this); email.setHint("you@example.com"); email.setTextSize(15); email.setSingleLine(true); email.setInputType(33); email.setPadding(dp(16),0,dp(16),0); email.setBackground(stroke(BORDER,1,Color.WHITE,15)); login.addView(email,new LinearLayout.LayoutParams(-1,dp(56)));
        TextView lpw=bold("Password",14,NAVY); lpw.setPadding(0,dp(14),0,dp(7)); login.addView(lpw);
        EditText pass=new EditText(this); pass.setHint("Your password"); pass.setTextSize(15); pass.setSingleLine(true); pass.setInputType(129); pass.setPadding(dp(16),0,dp(16),0); pass.setBackground(stroke(BORDER,1,Color.WHITE,15)); login.addView(pass,new LinearLayout.LayoutParams(-1,dp(56)));
        Button go=btn("Login  →",GREEN,Color.WHITE); LinearLayout.LayoutParams gp=new LinearLayout.LayoutParams(-1,dp(56)); gp.topMargin=dp(14); login.addView(go,gp);
        TextView note=tv("Use the email/password account created in Firebase Authentication.\nYour role is loaded automatically from Realtime Database.",12,MUTED); note.setGravity(Gravity.CENTER); note.setPadding(0,dp(16),0,0); p.addView(note);
        go.setOnClickListener(v->{hide(pass); hide(email); String e=email.getText().toString().trim(), pw=pass.getText().toString(); if(e.isEmpty()||pw.isEmpty()){toast("Enter email and password");return;} go.setEnabled(false); auth.signInWithEmailAndPassword(e,pw).addOnCompleteListener(t->{go.setEnabled(true); if(t.isSuccessful()) loadProfile(auth.getCurrentUser()); else toast("Login failed: "+(t.getException()==null?"Check your details":t.getException().getMessage()));});});
    }

    void loadProfile(FirebaseUser u){
        user=u;
        db.child("users").child(u.getUid()).addListenerForSingleValueEvent(new ValueEventListener(){
            public void onDataChange(DataSnapshot s){
                if(!s.exists()){showNoRole();return;}
                role=s.child("role").getValue(String.class)==null?"":s.child("role").getValue(String.class);
                currentName=s.child("name").getValue(String.class)==null?"User":s.child("name").getValue(String.class);
                memberId=s.child("memberId").getValue(String.class)==null?u.getUid():s.child("memberId").getValue(String.class);
                if(role.isEmpty()){showNoRole();return;}
                if(role.equalsIgnoreCase("admin")) adminHome(); else if(role.equalsIgnoreCase("staff")) staffHome(); else if(role.equalsIgnoreCase("member")) memberHome(); else showNoRole();
            }
            public void onCancelled(DatabaseError e){toast("Could not load profile: "+e.getMessage());}
        });
    }

    void showNoRole(){
        root(); LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setGravity(Gravity.CENTER);p.setPadding(dp(24),dp(30),dp(24),dp(30));root.addView(p,new LinearLayout.LayoutParams(-1,-1));
        p.addView(bold("🔐",52,GREEN)); TextView h=bold("Account not assigned",25,NAVY);h.setGravity(Gravity.CENTER);p.addView(h); TextView x=tv("Your Firebase account is valid, but no role is assigned yet.\nAsk the mess admin to set users/"+user.getUid()+"/role to admin, staff, or member.",14,MUTED);x.setGravity(Gravity.CENTER);x.setPadding(0,dp(12),0,dp(22));p.addView(x);Button out=btn("Logout",Color.WHITE,GREEN);out.setBackground(stroke(Color.rgb(187,247,208),1,Color.WHITE,17));p.addView(out,new LinearLayout.LayoutParams(-1,dp(54)));out.setOnClickListener(v->logout());
    }

    void logout(){for(DatabaseReference r:listeners.values()) r.removeEventListener(new ValueEventListener(){public void onDataChange(DataSnapshot s){}public void onCancelled(DatabaseError e){}});listeners.clear();auth.signOut();role="";currentName="";memberId="";showLogin();}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    String dateKey(){return new SimpleDateFormat("yyyy-MM-dd",Locale.US).format(new Date());}
    String date(){return new SimpleDateFormat("dd MMM yyyy",Locale.getDefault()).format(new Date());}
    String time(){return new SimpleDateFormat("hh:mm a",Locale.getDefault()).format(new Date());}

    void shell(String title,String subtitle){
        root();
        LinearLayout top=h();
        top.setPadding(dp(14),dp(8),dp(14),dp(6));
        ImageView brandLogo=logo(54);
        top.addView(brandLogo,new LinearLayout.LayoutParams(dp(54),dp(54)));
        LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.setPadding(dp(10),0,0,0);
        tx.addView(bold("Ranchi Lunch Box",18,NAVY));
        tx.addView(bold(title,15,GREEN));
        tx.addView(tv(subtitle,10,MUTED));
        top.addView(tx,new LinearLayout.LayoutParams(0,dp(62),1));
        Button logout=btn("↪",Color.WHITE,NAVY);logout.setBackground(stroke(BORDER,1,Color.WHITE,15));
        top.addView(logout,new LinearLayout.LayoutParams(dp(50),dp(48)));
        logout.setOnClickListener(v->logout());
        root.addView(top);
        View line=new View(this);line.setBackgroundColor(Color.rgb(226,235,227));root.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
        ScrollView sc=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(16),dp(8),dp(16),dp(94));sc.addView(body);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
    }
    void nav(String active,String a,String b,String c,String d,final Runnable ra,final Runnable rb,final Runnable rc,final Runnable rd){LinearLayout bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setGravity(Gravity.CENTER);bar.setPadding(dp(8),dp(8),dp(8),dp(8));bar.setBackgroundColor(Color.WHITE);String[][] x={{"⌂",a},{"▣",b},{"♟",c},{"☰",d}};Runnable[] rr={ra,rb,rc,rd};for(int j=0;j<4;j++){TextView t=tv(x[j][0]+"\n"+x[j][1],11,x[j][1].equals(active)?GREEN:MUTED);t.setGravity(Gravity.CENTER);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);final Runnable r=rr[j];t.setOnClickListener(v->r.run());bar.addView(t,new LinearLayout.LayoutParams(0,dp(60),1));}root.addView(bar,new LinearLayout.LayoutParams(-1,dp(76)));}
    void section(String s){TextView t=bold(s,14,NAVY);t.setPadding(dp(2),dp(16),0,dp(8));body.addView(t);}
    LinearLayout stat(String icon,String value,String label,int color){LinearLayout c=card();c.setGravity(Gravity.CENTER);c.addView(tv(icon,24,color));TextView v=bold(value,22,NAVY);v.setGravity(Gravity.CENTER);c.addView(v);TextView l=tv(label,11,MUTED);l.setGravity(Gravity.CENTER);c.addView(l);return c;}

    void adminHome(){shell("Good Morning, Admin 👋",date());section("Today's Overview");LinearLayout row=h();LinearLayout a=stat("👥","Live","Members",GREEN),b=stat("🍱","Live","Deliveries",BLUE),c=stat("🔔","Live","Alerts",ORANGE);for(LinearLayout z:new LinearLayout[]{a,b,c}){LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(0,dp(128),1);q.setMargins(dp(3),0,dp(3),0);row.addView(z,q);}body.addView(row);section("Admin controls");TextView info=tv("Firebase is connected. User roles are read from Realtime Database.\nCreate authentication users in Firebase Console, then assign /users/{uid}/role.",13,MUTED);body.addView(info);section("Quick Actions");Button m=btn("👥  Manage Members",Color.WHITE,GREEN);m.setBackground(stroke(Color.rgb(187,247,208),1,Color.WHITE,17));body.addView(m,new LinearLayout.LayoutParams(-1,dp(54)));m.setOnClickListener(v->adminMembers());Button r=btn("📊  Reports",Color.WHITE,BLUE);r.setBackground(stroke(Color.rgb(191,219,254),1,Color.WHITE,17));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(54));rp.topMargin=dp(10);body.addView(r,rp);r.setOnClickListener(v->adminReports());nav("Home","Home","Members","Reports","More",()->adminHome(),()->adminMembers(),()->adminReports(),()->adminMore());}
    void adminMembers(){shell("Members","Firebase-backed member profiles");section("How to add a member");body.addView(tv("1. Create the member's email/password in Firebase Authentication.\n2. Copy that user's UID.\n3. In Realtime Database create users/{UID} with role=member, name=..., memberId=... .\n4. The member can then log in from this app.",13,MUTED));Button dbb=btn("Open Realtime Database",GREEN,Color.WHITE);LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(54));bp.topMargin=dp(12);body.addView(dbb,bp);dbb.setOnClickListener(v->toast("Use Firebase Console → Realtime Database → Data"));nav("Members","Home","Members","Reports","More",()->adminHome(),()->adminMembers(),()->adminReports(),()->adminMore());}
    void adminReports(){shell("Reports","Realtime delivery data");section("Current account");body.addView(tv("Signed in as: "+currentName+"\nRole: "+role+"\nUID: "+user.getUid(),13,MUTED));section("Database path");body.addView(tv("deliveries/"+dateKey()+"/Lunch/{memberUid}\ndeliveries/"+dateKey()+"/Dinner/{memberUid}",13,NAVY));nav("Reports","Home","Members","Reports","More",()->adminHome(),()->adminMembers(),()->adminReports(),()->adminMore());}
    void adminMore(){shell("More","Account & settings");LinearLayout c=card();c.addView(bold("Firebase status",16,NAVY));c.addView(tv("Authentication: connected\nRealtime Database: connected\nNotifications: device permission requested",13,MUTED));body.addView(c);nav("More","Home","Members","Reports","More",()->adminHome(),()->adminMembers(),()->adminReports(),()->adminMore());}

    void staffHome(){shell("Hello, "+currentName+" 👋","Delivery panel • "+date());section(meal+" Delivery");TextView hint=tv("Tap Deliver for a member. The status is written to Firebase in real time.",13,MUTED);body.addView(hint);Button sw=btn("Switch to "+(meal.equals("Lunch")?"Dinner":"Lunch"),Color.WHITE,NAVY);sw.setBackground(stroke(BORDER,1,Color.WHITE,16));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,dp(50));sp.topMargin=dp(10);body.addView(sw,sp);sw.setOnClickListener(v->{meal=meal.equals("Lunch")?"Dinner":"Lunch";staffHome();});section("Members");loadMembersForStaff();nav("Home","Home","Deliveries","History","Profile",()->staffHome(),()->staffHome(),()->staffHistory(),()->staffProfile());}

    void loadMembersForStaff(){
        db.child("members").orderByChild("role").equalTo("member").addListenerForSingleValueEvent(new ValueEventListener(){
            public void onDataChange(DataSnapshot s){if(s.getChildrenCount()==0){body.addView(tv("No member profiles found yet. Add users with role=member in Realtime Database.",13,MUTED));return;}for(DataSnapshot x:s.getChildren()){String uid=x.getKey();String name=x.child("name").getValue(String.class);String room=x.child("room").getValue(String.class);if(name==null)name="Member";if(room==null)room="Room not set";staffRow(uid,name,room);}}
            public void onCancelled(DatabaseError e){body.addView(tv("Could not load members: "+e.getMessage(),13,RED));}
        });
    }
    void staffRow(String uid,String name,String room){
        LinearLayout c=card();c.setOrientation(LinearLayout.HORIZONTAL);LinearLayout i=new LinearLayout(this);i.setOrientation(LinearLayout.VERTICAL);i.addView(bold(name,16,NAVY));i.addView(tv(room,12,MUTED));c.addView(i,new LinearLayout.LayoutParams(0,dp(62),1));Button b=btn("Deliver",GREEN,Color.WHITE);c.addView(b,new LinearLayout.LayoutParams(dp(118),dp(50)));body.addView(c,new LinearLayout.LayoutParams(-1,dp(88)));
        db.child("deliveries").child(dateKey()).child(meal).child(uid).addListenerForSingleValueEvent(new ValueEventListener(){public void onDataChange(DataSnapshot s){if(s.child("delivered").getValue(Boolean.class)!=null&&s.child("delivered").getValue(Boolean.class)){b.setText("Delivered ✓");b.setTextColor(GREEN);b.setBackground(bg(Color.rgb(220,252,231),18));b.setEnabled(false);}}public void onCancelled(DatabaseError e){}});
        b.setOnClickListener(v->{Map<String,Object> m=new HashMap<>();m.put("delivered",true);m.put("deliveredAt",ServerValue.TIMESTAMP);m.put("staffUid",user.getUid());m.put("memberName",name);m.put("meal",meal);db.child("deliveries").child(dateKey()).child(meal).child(uid).updateChildren(m).addOnCompleteListener(t->{if(t.isSuccessful()){b.setText("Delivered ✓");b.setTextColor(GREEN);b.setBackground(bg(Color.rgb(220,252,231),18));b.setEnabled(false);toast("Delivery saved for "+name);sendTopicMessageHint();}else toast("Could not save delivery: "+t.getException());});});
    }
    void sendTopicMessageHint(){FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t->{if(t.isSuccessful()){} });}
    void staffHistory(){shell("Delivery History","Today • Firebase records");db.child("deliveries").child(dateKey()).child(meal).addListenerForSingleValueEvent(new ValueEventListener(){public void onDataChange(DataSnapshot s){if(!s.exists()){body.addView(tv("No deliveries recorded yet.",13,MUTED));return;}for(DataSnapshot x:s.getChildren()){String name=x.child("memberName").getValue(String.class);body.addView(tv("✓  "+(name==null?x.getKey():name)+" • "+meal,14,NAVY));}}public void onCancelled(DatabaseError e){toast(e.getMessage());}});nav("History","Home","Deliveries","History","Profile",()->staffHome(),()->staffHome(),()->staffHistory(),()->staffProfile());}
    void staffProfile(){shell("Staff Profile","Delivery account");LinearLayout c=card();c.addView(bold(currentName,20,NAVY));c.addView(tv("Staff • "+user.getEmail()+"\nUID: "+user.getUid(),13,MUTED));body.addView(c);nav("Profile","Home","Deliveries","History","Profile",()->staffHome(),()->staffHome(),()->staffHistory(),()->staffProfile());}

    void memberHome(){
        shell("Hello, "+currentName+" 👋","Your mess at a glance");section("Today's "+meal);LinearLayout c=card();c.addView(bold("Ranchi Lunch Box  •  "+meal,18,NAVY));TextView status=bold("Checking…",23,ORANGE);c.addView(status);c.addView(tv("Firebase realtime status",13,MUTED));body.addView(c);listenMemberDelivery(status,c);section("Account");body.addView(tv("Email: "+user.getEmail()+"\nMember ID: "+memberId,13,MUTED));nav("Home","Home","Attendance","Alerts","Profile",()->memberHome(),()->memberAttendance(),()->memberAlerts(),()->memberProfile());
    }
    void listenMemberDelivery(TextView status,LinearLayout card){String deliveryMemberId = memberId == null || memberId.isEmpty() ? user.getUid() : memberId;String path="deliveries/"+dateKey()+"/"+meal+"/"+deliveryMemberId;DatabaseReference r=db.child("deliveries").child(dateKey()).child(meal).child(deliveryMemberId);r.addValueEventListener(new ValueEventListener(){public void onDataChange(DataSnapshot s){Boolean d=s.child("delivered").getValue(Boolean.class);if(Boolean.TRUE.equals(d)){status.setText("Delivered ✓");status.setTextColor(GREEN);}else{status.setText("Waiting for delivery");status.setTextColor(ORANGE);}}public void onCancelled(DatabaseError e){status.setText("Unable to load status");status.setTextColor(RED);}});listeners.put(path,r);}
    void memberAttendance(){shell("Attendance","Firebase delivery history");body.addView(tv("Your attendance is derived from recorded meal deliveries.\nCurrent date: "+date(),13,MUTED));db.child("deliveries").child(dateKey()).addListenerForSingleValueEvent(new ValueEventListener(){public void onDataChange(DataSnapshot s){int count=0;for(DataSnapshot mealSnap:s.getChildren())String deliveryMemberId = memberId == null || memberId.isEmpty() ? user.getUid() : memberId;if(mealSnap.hasChild(deliveryMemberId))count++;body.addView(stat("✓",""+count,"Meals delivered today",GREEN),new LinearLayout.LayoutParams(-1,dp(120)));}public void onCancelled(DatabaseError e){}});nav("Attendance","Home","Attendance","Alerts","Profile",()->memberHome(),()->memberAttendance(),()->memberAlerts(),()->memberProfile());}
    void memberAlerts(){shell("Notifications","Delivery updates");body.addView(tv("Realtime delivery updates are shown on your Home screen. Push notifications will be enabled after the FCM server/topic step.",13,MUTED));nav("Alerts","Home","Attendance","Alerts","Profile",()->memberHome(),()->memberAttendance(),()->memberAlerts(),()->memberProfile());}
    void memberProfile(){shell("My Profile","Account & preferences");LinearLayout c=card();c.addView(bold(currentName,20,NAVY));c.addView(tv("Member • "+user.getEmail()+"\nMember ID: "+memberId,13,MUTED));body.addView(c);nav("Profile","Home","Attendance","Alerts","Profile",()->memberHome(),()->memberAttendance(),()->memberAlerts(),()->memberProfile());}
}
